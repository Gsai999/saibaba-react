import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={{backgroundColor:'white',flex:1}}>
<View style={{backgroundColor:'blue',height:20,margin:10,marginTop:10}}>
</View>

<View style={{backgroundColor:'blue',height:10,margin:10,marginTop:10}}>
</View>

<View style={{backgroundColor:'black',height:10,margin:30,marginTop:10}}>
</View>

<View style={{backgroundColor:'grey',height:110,margin:10,marginTop:0}}>
</View>

<View style={{backgroundColor:'black',height:30,margin:10,marginTop:20}}>
</View>


<View style={{backgroundColor:'black',height:5,margin:10,marginTop:20}}>
</View>

<View style={{backgroundColor:'black',height:30,margin:10,marginTop:20}}>
</View>

<View style={{backgroundColor:'red',height:30,margin:10,marginTop:0}}>
</View>

<View style={{backgroundColor:'red',height:30,width:110,margin:10,marginTop:0}}>
</View>

<View style={{backgroundColor:'red',height:30,margin:10,marginTop:0}}>
</View>

<View style={{backgroundColor:'red',height:30,margin:10,marginTop:0}}>
</View>








    </View>
  

);
}
